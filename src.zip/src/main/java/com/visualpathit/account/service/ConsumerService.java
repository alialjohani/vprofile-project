package com.visualpathit.account.service;

public interface ConsumerService {

    void consumerMessage(byte[] data);
}
